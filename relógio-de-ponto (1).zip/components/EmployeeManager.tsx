
import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  User, 
  Briefcase, 
  Hash, 
  Clock, 
  Plus, 
  Search, 
  Edit2, 
  Trash2, 
  CheckCircle2, 
  XCircle, 
  AlertCircle, 
  Palmtree, 
  Stethoscope, 
  Home, 
  PartyPopper,
  Lock,
  Camera,
  FileText,
  ChevronRight,
  X
} from 'lucide-react';
import { Employee, EmployeeStatus, AbsenceRecord } from '../types';

interface EmployeeManagerProps {
  employees: Employee[];
  records: AbsenceRecord[];
  onAdd: (emp: Omit<Employee, 'id'>) => void;
  onEdit: (emp: Employee) => void;
  onUpdateStatus: (id: string, status: EmployeeStatus, vStart?: string, vEnd?: string, aDate?: string, aReason?: string) => void;
  onDelete: (id: string) => void;
}

const EmployeeManager: React.FC<EmployeeManagerProps> = ({ employees, onAdd, onEdit, onUpdateStatus, onDelete }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [pinInput, setPinInput] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);

  const [isStatusModalOpen, setIsStatusModalOpen] = useState(false);
  const [selectedEmp, setSelectedEmp] = useState<Employee | null>(null);
  const [statusType, setStatusType] = useState<EmployeeStatus>(EmployeeStatus.VACATION);
  const [statusDates, setStatusDates] = useState({ start: '', end: '', reason: '' });

  const [formData, setFormData] = useState<Omit<Employee, 'id'> & { id?: string }>({ 
    name: '', role: '', code: '', status: EmployeeStatus.ACTIVE, avatar: '', dailyWorkHours: 8, notes: ''
  });

  const avatarUploadRef = useRef<HTMLInputElement>(null);

  const handleAuth = (e: React.FormEvent) => {
    e.preventDefault();
    if (pinInput === '2303') {
      setIsAuthenticated(true);
      setPinInput('');
    } else {
      alert('Código PIN de Administrador Incorreto!');
      setPinInput('');
    }
  };

  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setFormData({ ...formData, avatar: reader.result as string });
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isEditMode && formData.id) onEdit(formData as Employee);
    else onAdd(formData);
    setIsModalOpen(false);
    setFormData({ name: '', role: '', code: '', status: EmployeeStatus.ACTIVE, avatar: '', dailyWorkHours: 8, notes: '' });
  };

  const handleOpenStatus = (emp: Employee, type: EmployeeStatus) => {
    setSelectedEmp(emp);
    setStatusType(type);
    const today = new Date().toISOString().split('T')[0];
    setStatusDates({ 
      start: today, 
      end: type === EmployeeStatus.VACATION ? new Date(Date.now() + 15 * 86400000).toISOString().split('T')[0] : today, 
      reason: '' 
    });
    setIsStatusModalOpen(true);
  };

  const handleSaveStatus = () => {
    if (selectedEmp) {
      onUpdateStatus(selectedEmp.id, statusType, statusDates.start, statusDates.end, statusDates.start, statusDates.reason);
      setIsStatusModalOpen(false);
      setSelectedEmp(null);
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[70vh] px-4 animate-fade-in">
        <motion.form 
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          onSubmit={handleAuth} 
          className="glass p-12 rounded-[3rem] shadow-2xl text-center space-y-8 w-full max-w-sm border border-slate-100 dark:border-white/5"
        >
          <div className="flex flex-col items-center gap-4">
            <div className="w-20 h-20 bg-indigo-600 rounded-[2rem] flex items-center justify-center shadow-2xl text-white">
              <Lock className="w-10 h-10" />
            </div>
            <div>
              <h2 className="text-xl font-black uppercase text-slate-800 dark:text-white tracking-tight italic">Gestão Segura</h2>
              <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest mt-1">Acesso Restrito a Administradores</p>
            </div>
          </div>
          <input 
            type="password" 
            value={pinInput} 
            onChange={e => setPinInput(e.target.value.replace(/\D/g, '').slice(0, 4))} 
            placeholder="••••" 
            className="w-full bg-slate-50 dark:bg-slate-950 p-6 rounded-2xl text-center text-5xl font-mono tracking-[0.5em] outline-none border-2 border-transparent focus:border-indigo-600 transition-all dark:text-white shadow-inner" 
            autoFocus 
          />
          <button type="submit" className="w-full bg-indigo-600 text-white py-5 rounded-2xl font-black text-[11px] uppercase tracking-widest shadow-xl hover:bg-indigo-700 transition-all flex items-center justify-center gap-2">
            <CheckCircle2 className="w-4 h-4" />
            Validar Acesso
          </button>
        </motion.form>
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-fade-in pb-20">
      <div className="flex flex-col sm:flex-row justify-between items-center gap-4 bg-white dark:bg-slate-900 p-6 rounded-[2rem] border border-slate-100 dark:border-white/5 shadow-xl">
        <div className="flex items-center gap-4">
          <div className="p-4 bg-indigo-50 dark:bg-indigo-900/20 rounded-2xl text-indigo-600">
            <User className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-2xl font-black text-slate-900 dark:text-white uppercase tracking-tight italic leading-none">Colaboradores</h2>
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1">{employees.length} Staff Registado</p>
          </div>
        </div>
        <div className="flex gap-3 w-full sm:w-auto">
          <div className="relative flex-1 sm:w-64">
            <input 
              type="text" 
              placeholder="Nome ou código..." 
              value={searchTerm} 
              onChange={e => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-3 bg-slate-50 dark:bg-slate-950 rounded-xl text-xs font-bold outline-none border-2 border-transparent focus:border-indigo-500 transition-all dark:text-white shadow-inner"
            />
            <Search className="w-4 h-4 absolute left-3.5 top-3.5 text-slate-300" />
          </div>
          <button 
            onClick={() => { setFormData({ name: '', role: '', code: '', status: EmployeeStatus.ACTIVE, avatar: '', dailyWorkHours: 8 }); setIsEditMode(false); setIsModalOpen(true); }} 
            className="bg-indigo-600 text-white px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest shadow-lg hover:bg-indigo-700 transition-all flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            Novo Staff
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        <AnimatePresence>
          {employees.filter(emp => emp.name.toLowerCase().includes(searchTerm.toLowerCase()) || emp.code.includes(searchTerm)).map(emp => (
            <motion.div 
              layout
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9 }}
              key={emp.id} 
              className="bg-white dark:bg-slate-900 rounded-[2.5rem] p-8 shadow-xl border border-slate-100 dark:border-white/5 flex flex-col min-h-[20rem] hover:shadow-2xl transition-all group"
            >
              <div className="flex items-start justify-between mb-6">
                <div className="flex items-center gap-4">
                  <div className="w-20 h-20 rounded-[1.5rem] bg-slate-50 dark:bg-slate-800 border-2 border-slate-100 dark:border-white/5 overflow-hidden flex items-center justify-center flex-shrink-0 shadow-inner group-hover:border-indigo-500/30 transition-all">
                    {emp.avatar ? (
                      <img src={emp.avatar} alt={emp.name} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center bg-indigo-50 dark:bg-indigo-900/20">
                        <span className="text-3xl font-black text-indigo-300">{emp.name[0]}</span>
                      </div>
                    )}
                  </div>
                  <div className="min-w-0">
                    <h3 className="font-black text-slate-900 dark:text-white uppercase text-sm truncate tracking-tight italic">{emp.name}</h3>
                    <div className="flex items-center gap-1 mt-1">
                      <Briefcase className="w-2.5 h-2.5 text-indigo-500" />
                      <p className="text-[9px] font-bold text-indigo-500 uppercase tracking-widest truncate">{emp.role}</p>
                    </div>
                    <div className="flex items-center gap-1 mt-0.5">
                      <Hash className="w-2.5 h-2.5 text-slate-300" />
                      <p className="text-[9px] font-bold text-slate-300 uppercase tracking-widest">{emp.code}</p>
                    </div>
                  </div>
                </div>
                <div className={`px-3 py-1.5 rounded-xl text-[8px] font-black uppercase tracking-widest border shadow-sm flex items-center gap-1.5 ${
                  emp.status === EmployeeStatus.ACTIVE ? 'bg-emerald-50 text-emerald-600 border-emerald-100' : 
                  emp.status === EmployeeStatus.VACATION ? 'bg-amber-50 text-amber-600 border-amber-100' : 
                  emp.status === EmployeeStatus.SICK_LEAVE ? 'bg-indigo-50 text-indigo-600 border-indigo-100' :
                  emp.status === EmployeeStatus.OFF ? 'bg-slate-50 text-slate-600 border-slate-100' :
                  emp.status === EmployeeStatus.HOLIDAY ? 'bg-purple-50 text-purple-600 border-purple-100' :
                  emp.status === EmployeeStatus.INACTIVE ? 'bg-slate-100 text-slate-400 border-slate-200' :
                  'bg-rose-50 text-rose-600 border-rose-100'
                }`}>
                  {emp.status === EmployeeStatus.ACTIVE && <CheckCircle2 className="w-2.5 h-2.5" />}
                  {emp.status === EmployeeStatus.VACATION && <Palmtree className="w-2.5 h-2.5" />}
                  {emp.status === EmployeeStatus.SICK_LEAVE && <Stethoscope className="w-2.5 h-2.5" />}
                  {emp.status === EmployeeStatus.ABSENT && <XCircle className="w-2.5 h-2.5" />}
                  {emp.status === EmployeeStatus.ACTIVE ? 'Ativo' : 
                   emp.status === EmployeeStatus.VACATION ? 'Férias' : 
                   emp.status === EmployeeStatus.SICK_LEAVE ? 'Baixa' :
                   emp.status === EmployeeStatus.OFF ? 'Folga' :
                   emp.status === EmployeeStatus.HOLIDAY ? 'Feriado' : 
                   emp.status === EmployeeStatus.INACTIVE ? 'Desativado' : 'Falta'}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 mb-6">
                <div className="bg-slate-50 dark:bg-slate-950/50 p-4 rounded-2xl border border-transparent hover:border-slate-100 dark:hover:border-white/5 transition-all">
                  <div className="flex items-center gap-1.5 mb-1 opacity-40">
                    <Clock className="w-2.5 h-2.5" />
                    <p className="text-[7px] font-black uppercase tracking-widest">Carga Diária</p>
                  </div>
                  <p className="text-xs font-black text-slate-800 dark:text-slate-100 font-mono">{emp.dailyWorkHours}H / DIA</p>
                </div>
                <div className="bg-slate-50 dark:bg-slate-950/50 p-4 rounded-2xl border border-transparent hover:border-slate-100 dark:hover:border-white/5 transition-all">
                  <div className="flex items-center gap-1.5 mb-1 opacity-40">
                    <FileText className="w-2.5 h-2.5" />
                    <p className="text-[7px] font-black uppercase tracking-widest">Observações</p>
                  </div>
                  <p className="text-[9px] font-bold text-slate-600 dark:text-slate-400 italic truncate">{emp.notes || 'Sem notas...'}</p>
                </div>
              </div>

              <div className="space-y-3 mt-auto">
                <div className="flex gap-2">
                  {emp.status === EmployeeStatus.ACTIVE ? (
                    <div className="flex-1 grid grid-cols-3 gap-2">
                      <button 
                        onClick={() => handleOpenStatus(emp, EmployeeStatus.VACATION)}
                        className="bg-amber-50 dark:bg-amber-900/20 text-amber-600 p-3 rounded-xl text-[8px] font-black uppercase tracking-widest hover:bg-amber-100 transition-all flex flex-col items-center gap-1"
                        title="Férias"
                      >
                        <Palmtree className="w-4 h-4" />
                        Férias
                      </button>
                      <button 
                        onClick={() => handleOpenStatus(emp, EmployeeStatus.ABSENT)}
                        className="bg-rose-50 dark:bg-rose-900/20 text-rose-600 p-3 rounded-xl text-[8px] font-black uppercase tracking-widest hover:bg-rose-100 transition-all flex flex-col items-center gap-1"
                        title="Falta"
                      >
                        <XCircle className="w-4 h-4" />
                        Falta
                      </button>
                      <button 
                        onClick={() => handleOpenStatus(emp, EmployeeStatus.SICK_LEAVE)}
                        className="bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 p-3 rounded-xl text-[8px] font-black uppercase tracking-widest hover:bg-indigo-100 transition-all flex flex-col items-center gap-1"
                        title="Baixa"
                      >
                        <Stethoscope className="w-4 h-4" />
                        Baixa
                      </button>
                    </div>
                  ) : (
                    <button 
                      onClick={() => onUpdateStatus(emp.id, EmployeeStatus.ACTIVE)}
                      className="flex-1 bg-emerald-600 text-white py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-emerald-700 transition-all shadow-lg flex items-center justify-center gap-2"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      Reativar Colaborador
                    </button>
                  )}
                </div>
                
                <div className="flex gap-2">
                  <button 
                    onClick={() => onUpdateStatus(emp.id, emp.status === EmployeeStatus.INACTIVE ? EmployeeStatus.ACTIVE : EmployeeStatus.INACTIVE)}
                    className={`flex-1 py-3 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all shadow-sm flex items-center justify-center gap-2 ${emp.status === EmployeeStatus.INACTIVE ? 'bg-emerald-50 text-emerald-600 hover:bg-emerald-100' : 'bg-slate-50 text-slate-400 hover:bg-slate-100'}`}
                  >
                    {emp.status === EmployeeStatus.INACTIVE ? <CheckCircle2 className="w-3 h-3" /> : <XCircle className="w-3 h-3" />}
                    {emp.status === EmployeeStatus.INACTIVE ? 'Ativar Staff' : 'Desativar'}
                  </button>
                  <button 
                    onClick={() => { setFormData(emp); setIsEditMode(true); setIsModalOpen(true); }}
                    className="p-3 bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600 rounded-xl hover:bg-indigo-600 hover:text-white transition-all shadow-sm"
                    title="Editar Perfil"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button 
                    onClick={() => setConfirmDeleteId(emp.id)}
                    className="p-3 bg-rose-50 dark:bg-rose-900/20 text-rose-600 rounded-xl hover:bg-rose-600 hover:text-white transition-all shadow-sm"
                    title="Eliminar"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {confirmDeleteId && (
        <div className="fixed inset-0 bg-slate-950/90 backdrop-blur-md z-[200] flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-[2rem] shadow-2xl w-full max-w-sm p-10 text-center animate-slide-up border dark:border-white/5">
            <h3 className="text-lg font-black text-slate-900 dark:text-white uppercase italic mb-2">Eliminar?</h3>
            <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mb-8">Esta ação é irreversível.</p>
            <div className="flex gap-4">
              <button onClick={() => setConfirmDeleteId(null)} className="flex-1 py-4 text-[10px] font-black uppercase text-slate-400">Voltar</button>
              <button onClick={() => { onDelete(confirmDeleteId); setConfirmDeleteId(null); }} className="flex-[2] bg-rose-600 text-white py-4 rounded-xl text-[10px] font-black uppercase">Confirmar</button>
            </div>
          </div>
        </div>
      )}

      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="bg-white dark:bg-slate-900 rounded-[3rem] shadow-2xl w-full max-w-md p-10 border dark:border-white/5"
            >
              <div className="flex justify-between items-center mb-8">
                <div className="flex items-center gap-3">
                  <div className="p-3 bg-indigo-50 dark:bg-indigo-900/20 rounded-2xl text-indigo-600">
                    {isEditMode ? <Edit2 className="w-5 h-5" /> : <Plus className="w-5 h-5" />}
                  </div>
                  <h3 className="text-xl font-black text-slate-900 dark:text-white uppercase tracking-tight italic">{isEditMode ? 'Editar Perfil' : 'Novo Staff'}</h3>
                </div>
                <button onClick={() => setIsModalOpen(false)} className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full transition-all">
                  <X className="w-5 h-5 text-slate-400" />
                </button>
              </div>

              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="flex justify-center">
                  <div className="w-24 h-24 rounded-[2rem] bg-slate-50 dark:bg-slate-950 border-2 border-dashed border-slate-200 dark:border-slate-800 flex items-center justify-center cursor-pointer overflow-hidden shadow-inner group relative hover:border-indigo-500 transition-all" onClick={() => avatarUploadRef.current?.click()}>
                    {formData.avatar ? (
                      <img src={formData.avatar} className="w-full h-full object-cover" />
                    ) : (
                      <div className="flex flex-col items-center gap-1 text-slate-300 group-hover:text-indigo-500 transition-all">
                        <Camera className="w-6 h-6" />
                        <span className="text-[8px] font-black uppercase tracking-widest">Foto</span>
                      </div>
                    )}
                    <div className="absolute inset-0 bg-indigo-600/0 group-hover:bg-indigo-600/10 transition-all" />
                  </div>
                  <input type="file" ref={avatarUploadRef} className="hidden" accept="image/*" onChange={handleAvatarChange} />
                </div>
                <div className="space-y-4">
                  <div className="space-y-1">
                    <label className="text-[8px] font-black text-slate-400 uppercase tracking-widest ml-1">Nome Completo</label>
                    <input type="text" required value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} className="w-full bg-slate-50 dark:bg-slate-950 px-5 py-4 rounded-2xl text-xs font-bold dark:text-white outline-none border-2 border-transparent focus:border-indigo-600 transition-all shadow-inner" placeholder="Ex: João Silva" />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[8px] font-black text-slate-400 uppercase tracking-widest ml-1">Cargo / Função</label>
                    <input type="text" required value={formData.role} onChange={e => setFormData({...formData, role: e.target.value})} className="w-full bg-slate-50 dark:bg-slate-950 px-5 py-4 rounded-2xl text-xs font-bold dark:text-white outline-none border-2 border-transparent focus:border-indigo-600 transition-all shadow-inner" placeholder="Ex: Gerente" />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="text-[8px] font-black text-slate-400 uppercase tracking-widest ml-1 text-center block">PIN Acesso</label>
                      <input type="text" maxLength={4} required value={formData.code} onChange={e => setFormData({...formData, code: e.target.value.replace(/\D/g, '')})} className="w-full bg-slate-50 dark:bg-slate-950 px-5 py-4 rounded-2xl text-center font-mono text-xl font-black dark:text-white outline-none border-2 border-transparent focus:border-indigo-600 transition-all shadow-inner" placeholder="0000" />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[8px] font-black text-slate-400 uppercase tracking-widest ml-1 text-center block">Horas/Dia</label>
                      <input type="number" required value={formData.dailyWorkHours} onChange={e => setFormData({...formData, dailyWorkHours: Number(e.target.value)})} className="w-full bg-slate-50 dark:bg-slate-950 px-5 py-4 rounded-2xl text-center text-xs font-black dark:text-white outline-none border-2 border-transparent focus:border-indigo-600 transition-all shadow-inner" placeholder="8" />
                    </div>
                  </div>
                  <div className="space-y-1">
                    <label className="text-[8px] font-black text-slate-400 uppercase tracking-widest ml-1">Notas Adicionais</label>
                    <textarea value={formData.notes} onChange={e => setFormData({...formData, notes: e.target.value})} className="w-full bg-slate-50 dark:bg-slate-950 px-5 py-4 rounded-2xl text-xs font-bold dark:text-white outline-none border-2 border-transparent focus:border-indigo-600 transition-all h-24 resize-none shadow-inner" placeholder="Informações relevantes..." />
                  </div>
                </div>
                <div className="flex gap-4 pt-4">
                  <button type="button" onClick={() => setIsModalOpen(false)} className="flex-1 py-4 text-[10px] font-black uppercase text-slate-400 hover:text-slate-600 transition-all">Cancelar</button>
                  <button type="submit" className="flex-[2] bg-indigo-600 text-white py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-xl hover:bg-indigo-700 transition-all flex items-center justify-center gap-2">
                    <CheckCircle2 className="w-4 h-4" />
                    Guardar Staff
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {isStatusModalOpen && (
          <div className="fixed inset-0 bg-slate-950/90 backdrop-blur-md z-[150] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="bg-white dark:bg-slate-900 rounded-[3rem] shadow-2xl w-full max-w-sm p-10 border dark:border-white/5"
            >
              <div className="flex justify-between items-center mb-8">
                <div className="flex items-center gap-3">
                  <div className="p-3 bg-amber-50 dark:bg-amber-900/20 rounded-2xl text-amber-600">
                    <AlertCircle className="w-5 h-5" />
                  </div>
                  <h3 className="text-lg font-black text-slate-900 dark:text-white uppercase italic">Alterar Estado</h3>
                </div>
                <button onClick={() => setIsStatusModalOpen(false)} className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full transition-all">
                  <X className="w-5 h-5 text-slate-400" />
                </button>
              </div>

              <div className="space-y-6">
                <div className="space-y-1">
                  <label className="text-[8px] font-black text-slate-400 uppercase tracking-widest ml-1">Novo Estado</label>
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      { val: EmployeeStatus.VACATION, label: 'FÉRIAS', icon: '🌴' },
                      { val: EmployeeStatus.ABSENT, label: 'FALTA', icon: '⚠️' },
                      { val: EmployeeStatus.SICK_LEAVE, label: 'BAIXA', icon: '🤒' },
                      { val: EmployeeStatus.OFF, label: 'FOLGA', icon: '🏠' },
                      { val: EmployeeStatus.HOLIDAY, label: 'FERIADO', icon: '🎉' }
                    ].map(opt => (
                      <label key={opt.val} className="relative cursor-pointer group">
                        <input type="radio" name="statusType" value={opt.val} checked={statusType === opt.val} onChange={() => setStatusType(opt.val as EmployeeStatus)} className="peer sr-only" />
                        <div className="p-3 bg-slate-50 dark:bg-slate-950 rounded-xl border-2 border-transparent peer-checked:border-indigo-600 peer-checked:bg-indigo-50 dark:peer-checked:bg-indigo-900/20 transition-all flex items-center gap-2">
                          <span className="text-sm">{opt.icon}</span>
                          <span className="text-[9px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400 peer-checked:text-indigo-600">{opt.label}</span>
                        </div>
                      </label>
                    ))}
                  </div>
                </div>
                <div className={`grid ${statusType === EmployeeStatus.VACATION || statusType === EmployeeStatus.SICK_LEAVE || statusType === EmployeeStatus.OFF ? 'grid-cols-2' : 'grid-cols-1'} gap-4`}>
                  <div className="space-y-1">
                    <label className="text-[8px] font-black text-slate-400 uppercase tracking-widest ml-1">Início</label>
                    <input type="date" value={statusDates.start} onChange={e => setStatusDates({...statusDates, start: e.target.value})} className="w-full bg-slate-50 dark:bg-slate-950 px-4 py-4 rounded-2xl text-xs font-bold dark:text-white outline-none border-2 border-transparent focus:border-indigo-500 transition-all shadow-inner" />
                  </div>
                  { (statusType === EmployeeStatus.VACATION || statusType === EmployeeStatus.SICK_LEAVE || statusType === EmployeeStatus.OFF) && (
                    <div className="space-y-1">
                      <label className="text-[8px] font-black text-slate-400 uppercase tracking-widest ml-1">Fim</label>
                      <input type="date" value={statusDates.end} onChange={e => setStatusDates({...statusDates, end: e.target.value})} className="w-full bg-slate-50 dark:bg-slate-950 px-4 py-4 rounded-2xl text-xs font-bold dark:text-white outline-none border-2 border-transparent focus:border-indigo-500 transition-all shadow-inner" />
                    </div>
                  )}
                </div>
                <div className="space-y-1">
                  <label className="text-[8px] font-black text-slate-400 uppercase tracking-widest ml-1">Motivo / Justificação</label>
                  <textarea value={statusDates.reason} onChange={e => setStatusDates({...statusDates, reason: e.target.value})} placeholder="Descreva o motivo..." className="w-full bg-slate-50 dark:bg-slate-950 px-5 py-4 rounded-2xl text-xs font-bold h-24 dark:text-white outline-none border-2 border-transparent focus:border-indigo-500 transition-all resize-none shadow-inner" />
                </div>
                <div className="flex gap-4 pt-4">
                  <button type="button" onClick={() => setIsStatusModalOpen(false)} className="flex-1 py-4 text-[10px] font-black uppercase text-slate-400 hover:text-slate-600 transition-all">Voltar</button>
                  <button onClick={handleSaveStatus} className={`flex-[2] text-white py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-xl hover:opacity-90 transition-all flex items-center justify-center gap-2 ${
                    statusType === EmployeeStatus.VACATION ? 'bg-amber-600' : 
                    statusType === EmployeeStatus.SICK_LEAVE ? 'bg-indigo-600' :
                    statusType === EmployeeStatus.OFF ? 'bg-slate-600' :
                    statusType === EmployeeStatus.HOLIDAY ? 'bg-purple-600' :
                    'bg-rose-600'
                  }`}>
                    <CheckCircle2 className="w-4 h-4" />
                    Confirmar
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default EmployeeManager;
