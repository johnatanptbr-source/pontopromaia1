
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Search, 
  Filter, 
  Calendar, 
  Plus, 
  Trash2, 
  Edit2, 
  CheckCircle2, 
  AlertCircle, 
  Clock, 
  Palmtree, 
  Stethoscope, 
  Home, 
  PartyPopper,
  ChevronRight,
  MoreHorizontal,
  X,
  Lock
} from 'lucide-react';
import { Punch, Employee, PunchType, AbsenceRecord, EntryMethod, EntryModality, LocationConfig, EmployeeStatus } from '../types';
import { isWeekend, getHolidayName } from '../services/holidayService';

interface HistoryViewProps {
  punches: Punch[];
  employees: Employee[];
  records: AbsenceRecord[];
  locationConfig: LocationConfig;
  onSyncDay: (empId: string, date: string, newPunches: Punch[]) => void;
  onAddRecord: (record: AbsenceRecord) => void;
  onEditRecord: (record: AbsenceRecord) => void;
  onDeletePunch: (punchId: string) => void;
  onDeleteRecord: (recordId: string) => void;
  onDeleteRecords: (recordIds: string[]) => void;
  onClearPunches: () => void;
}

const HistoryView: React.FC<HistoryViewProps> = ({ 
  punches, employees, records, 
  onSyncDay, onAddRecord, onEditRecord, onDeleteRecord, onDeleteRecords,
  onClearPunches
}) => {
  const [activeTab, setActiveTab] = useState<'SUMMARY' | 'DETAILED' | 'ABSENCES'>('SUMMARY');
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [startDate, setStartDate] = useState(new Date().toISOString().split('T')[0]);
  const [showAllHistory, setShowAllHistory] = useState(false);
  
  const [isPinModalOpen, setIsPinModalOpen] = useState(false);
  const [pinValue, setPinValue] = useState('');
  const [pendingAction, setPendingAction] = useState<{ fn: () => void } | null>(null);

  const [isEditDayModalOpen, setIsEditDayModalOpen] = useState(false);
  const [isManualAddModalOpen, setIsManualAddModalOpen] = useState(false);
  const [isAddAbsenceModalOpen, setIsAddAbsenceModalOpen] = useState(false);
  const [isEditVacationModalOpen, setIsEditVacationModalOpen] = useState(false);
  
  const [selectedRows, setSelectedRows] = useState<string[]>([]);
  
  const [editDayData, setEditDayData] = useState<{ 
    emp: Employee, 
    date: string, 
    e1: string, s1: string, e2: string, s2: string, 
    notes: string 
  } | null>(null);

  const [editVacationData, setEditVacationData] = useState<AbsenceRecord | null>(null);
  const [showSuccessToast, setShowSuccessToast] = useState(false);

  useEffect(() => {
    if (showSuccessToast) {
      const timer = setTimeout(() => setShowSuccessToast(false), 3000);
      return () => clearTimeout(timer);
    }
  }, [showSuccessToast]);

  const todayStr = new Date().toISOString().split('T')[0];

  const requestAuth = (action: () => void) => {
    setPendingAction({ fn: action });
    setIsPinModalOpen(true);
  };

  const handlePinSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (pinValue === '2303') {
      setIsPinModalOpen(false);
      const actionToRun = pendingAction?.fn;
      setPinValue('');
      setPendingAction(null);
      if (actionToRun) actionToRun();
    } else {
      alert('PIN Administrador Incorreto!');
      setPinValue('');
    }
  };

  const toggleRowSelection = (id: string) => {
    setSelectedRows(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);
  };

  const handleDeleteSelected = () => {
    if (selectedRows.length === 0) return;
    requestAuth(() => {
      if (activeTab === 'ABSENCES') {
        onDeleteRecords(selectedRows);
      } else {
        selectedRows.forEach(id => {
          const [empId, date] = id.split('|');
          onSyncDay(empId, date, []);
        });
      }
      setSelectedRows([]);
    });
  };

  const openEditDay = (emp: Employee, date: string) => {
    const dayPunches = punches.filter(p => p.employeeId === emp.id && p.timestamp.startsWith(date)).sort((a,b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
    const getT = (idx: number) => {
      if (!dayPunches[idx]) return '';
      const d = new Date(dayPunches[idx].timestamp);
      return d.toLocaleTimeString('pt-PT', {hour:'2-digit', minute:'2-digit', timeZone: 'UTC'});
    };
    setEditDayData({
      emp, date, e1: getT(0), s1: getT(1), e2: getT(2), s2: getT(3),
      notes: Array.from(new Set(dayPunches.map(p => p.notes).filter(Boolean))).join(' | ')
    });
    setIsEditDayModalOpen(true);
  };

  const openEditVacation = (record: AbsenceRecord) => {
    setEditVacationData(record);
    setIsEditVacationModalOpen(true);
  };

  const handleEditVacationSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!editVacationData) return;
    const fd = new FormData(e.currentTarget);
    onEditRecord({
      ...editVacationData,
      type: fd.get('type') as AbsenceRecord['type'],
      date: fd.get('date') as string,
      endDate: fd.get('endDate') as string,
      reason: fd.get('reason') as string
    });
    setIsEditVacationModalOpen(false);
    setEditVacationData(null);
    setShowSuccessToast(true);
  };

  const handleEditDaySubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!editDayData) return;
    const fd = new FormData(e.currentTarget);
    const times = [fd.get('e1'), fd.get('s1'), fd.get('e2'), fd.get('s2')].map(v => v as string);
    const notes = fd.get('notes') as string;

    const newPunches: Punch[] = [];
    times.forEach((t, i) => {
      if (t && t.trim() !== "") {
        newPunches.push({
          id: Math.random().toString(36).substr(2, 9),
          employeeId: editDayData.emp.id,
          type: i % 2 === 0 ? PunchType.IN : PunchType.OUT,
          timestamp: `${editDayData.date}T${t}:00.000Z`,
          entryMethod: EntryMethod.MANUAL,
          modality: EntryModality.PIN,
          notes
        });
      }
    });

    onSyncDay(editDayData.emp.id, editDayData.date, newPunches);
    setIsEditDayModalOpen(false);
    setEditDayData(null);
  };

  const handleManualAddSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const empId = fd.get('employeeId') as string;
    const date = fd.get('date') as string;
    const times = [fd.get('e1'), fd.get('s1'), fd.get('e2'), fd.get('s2')].map(v => v as string);
    const notes = fd.get('notes') as string;

    const newPunches: Punch[] = [];
    times.forEach((t, i) => {
      if (t && t.trim() !== "") {
        newPunches.push({
          id: Math.random().toString(36).substr(2, 9),
          employeeId: empId,
          type: i % 2 === 0 ? PunchType.IN : PunchType.OUT,
          timestamp: `${date}T${t}:00.000Z`,
          entryMethod: EntryMethod.MANUAL,
          modality: EntryModality.PIN,
          notes
        });
      }
    });

    onSyncDay(empId, date, newPunches);
    setIsManualAddModalOpen(false);
  };

  const handleAddAbsenceSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const empId = fd.get('employeeId') as string;
    
    const newRecord: AbsenceRecord = {
      id: Math.random().toString(36).substr(2, 9),
      employeeId: empId,
      type: fd.get('type') as AbsenceRecord['type'],
      date: fd.get('date') as string,
      endDate: fd.get('endDate') as string || undefined,
      reason: fd.get('reason') as string
    };

    onAddRecord(newRecord);
    setIsAddAbsenceModalOpen(false);
    setShowSuccessToast(true);
  };

  const getStatusInfo = (dayRecord: AbsenceRecord | undefined, dateStr: string, punchCount: number) => {
    const isPast = dateStr < todayStr;
    const holidayName = getHolidayName(dateStr);
    const weekend = isWeekend(dateStr);

    if (dayRecord) {
      switch(dayRecord.type) {
        case 'VACATION': return { label: 'FÉRIAS', icon: <Palmtree className="w-3 h-3" />, color: 'text-amber-600 bg-amber-50 border-amber-100 dark:bg-amber-900/20 dark:border-amber-500/30', key: 'VACATION' };
        case 'ABSENCE': return { label: 'FALTA', icon: <AlertCircle className="w-3 h-3" />, color: 'text-rose-600 bg-rose-50 border-rose-100 dark:bg-rose-900/20 dark:border-rose-500/30', key: 'ABSENCE' };
        case 'SICK_LEAVE': return { label: 'BAIXA', icon: <Stethoscope className="w-3 h-3" />, color: 'text-indigo-600 bg-indigo-50 border-indigo-100 dark:bg-indigo-900/20 dark:border-indigo-500/30', key: 'SICK_LEAVE' };
        case 'OFF': return { label: 'FOLGA', icon: <Home className="w-3 h-3" />, color: 'text-slate-400 bg-slate-50 border-slate-100 dark:bg-slate-800 dark:border-slate-700', key: 'OFF' };
        case 'HOLIDAY': return { label: 'FERIADO', icon: <PartyPopper className="w-3 h-3" />, color: 'text-purple-600 bg-purple-50 border-purple-100 dark:bg-purple-900/20 dark:border-purple-500/30', key: 'HOLIDAY' };
        case 'DONE': return { label: 'CONCLUÍDO', icon: <CheckCircle2 className="w-3 h-3" />, color: 'text-emerald-600 bg-emerald-50 border-emerald-100 dark:bg-emerald-900/20 dark:border-emerald-500/30', key: 'DONE' };
        case 'REST': return { label: 'DESCANSO', icon: <Home className="w-3 h-3" />, color: 'text-slate-400 bg-slate-50 border-slate-100 dark:bg-slate-800 dark:border-slate-700', key: 'REST' };
        default: return { label: 'CONCLUÍDO', icon: <CheckCircle2 className="w-3 h-3" />, color: 'text-emerald-600 bg-emerald-50 border-emerald-100 dark:bg-emerald-900/20 dark:border-emerald-500/30', key: 'DONE' };
      }
    }

    if (holidayName && punchCount === 0) return { label: holidayName.toUpperCase(), icon: <PartyPopper className="w-3 h-3" />, color: 'text-purple-600 bg-purple-50 border-purple-100 dark:bg-purple-900/20 dark:border-purple-500/30', key: 'HOLIDAY' };
    if (weekend && punchCount === 0) return { label: 'DESCANSO', icon: <Home className="w-3 h-3" />, color: 'text-slate-400 bg-slate-50 border-slate-100 dark:bg-slate-800 dark:border-slate-700', key: 'REST' };

    if (punchCount === 0) {
      return isPast 
        ? { label: 'FALTA', icon: <AlertCircle className="w-3 h-3" />, color: 'text-rose-600 bg-rose-50 border-rose-100 dark:bg-rose-900/20 dark:border-rose-500/30', key: 'ABSENCE' }
        : { label: 'AUSENTE', icon: <Clock className="w-3 h-3" />, color: 'text-slate-400 bg-slate-50 border-slate-100 dark:bg-slate-800 dark:border-slate-700', key: 'ABSENCE' };
    }
    if (punchCount % 2 !== 0) return { label: 'EM CURSO', icon: <Clock className="w-3 h-3" />, color: 'text-amber-600 bg-amber-50 border-amber-100 dark:bg-amber-900/20 dark:border-amber-500/30', key: 'INCOMPLETE' };
    return { label: 'CONCLUÍDO', icon: <CheckCircle2 className="w-3 h-3" />, color: 'text-emerald-600 bg-emerald-50 border-emerald-100 dark:bg-emerald-900/20 dark:border-emerald-500/30', key: 'DONE' };
  };

  const renderPunchLine = (empPunches: Punch[]) => {
    const sorted = [...empPunches].sort((a,b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
    const numBoxes = Math.max(2, sorted.length);
    const boxesToRender = Array.from({ length: numBoxes }, (_, i) => i);

    return (
      <div className="flex flex-nowrap gap-2 justify-center">
        {boxesToRender.map(i => {
          const p = sorted[i];
          if (!p) return <div key={i} className="w-[60px] h-[32px] border border-dashed border-slate-200 dark:border-slate-800 rounded-lg flex items-center justify-center text-[10px] font-bold text-slate-300">--:--</div>;
          const time = new Date(p.timestamp).toLocaleTimeString('pt-PT', {hour:'2-digit', minute:'2-digit', timeZone: 'UTC'});
          const label = p.type === PunchType.IN ? 'E' : 'S';
          return (
            <div key={p.id} className={`w-[60px] h-[32px] rounded-lg flex flex-col items-center justify-center text-[10px] font-black border-2 relative shadow-sm transition-all hover:shadow-md ${p.type === PunchType.IN ? 'bg-indigo-50 border-indigo-100 text-indigo-700' : 'bg-slate-50 border-slate-100 text-slate-500'}`}>
              <div className="flex items-center">
                <span className="opacity-40 mr-0.5">{label}{Math.ceil((i+1)/2)}:</span>{time}
              </div>
              {p.location && (
                <div className="absolute -top-1.5 -right-1.5 bg-emerald-500 text-white rounded-full p-0.5 shadow-sm">
                  <svg className="w-2 h-2" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd" /></svg>
                </div>
              )}
            </div>
          );
        })}
      </div>
    );
  };

  const getConsolidatedRows = (filterDate: string, all: boolean, currentStatusFilter: string) => {
    const data: any[] = [];
    employees.forEach(emp => {
      let dates: string[] = all ? Array.from(new Set<string>(punches.filter(p => p.employeeId === emp.id).map(p => p.timestamp.split('T')[0]))).sort().reverse() : [filterDate];
      if (all && !dates.includes(todayStr)) dates.unshift(todayStr);
      dates.forEach((d: string) => {
        const dayPunches = punches.filter(p => p.employeeId === emp.id && p.timestamp.startsWith(d));
        let dayRecord = records.find(r => r.employeeId === emp.id && (d === r.date || (r.endDate && d >= r.date && d <= r.endDate)));
        
        // If it's today and employee is explicitly ACTIVE, ignore the record for status
        if (d === todayStr && emp.status === EmployeeStatus.ACTIVE && dayRecord) {
          dayRecord = undefined;
        }
        
        const status = getStatusInfo(dayRecord, d, dayPunches.length);
        const notes = Array.from(new Set(dayPunches.map(p => p.notes).filter(Boolean))).join(' | ');
        if ((!searchTerm || emp.name.toLowerCase().includes(searchTerm.toLowerCase()) || emp.code.includes(searchTerm)) && (currentStatusFilter === 'ALL' || status.key === currentStatusFilter)) {
          data.push({ emp, date: d, dayPunches, status, notes });
        }
      });
    });
    return data;
  };

  const currentRows = getConsolidatedRows(startDate, showAllHistory, statusFilter);
  const absenceRecords = records.filter(r => ['VACATION', 'ABSENCE', 'SICK_LEAVE', 'OFF', 'HOLIDAY', 'REST'].includes(r.type)).filter(r => {
    const emp = employees.find(e => e.id === r.employeeId);
    const matchesSearch = !searchTerm || (emp && (
      emp.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
      emp.code.includes(searchTerm)
    ));
    
    // Map status filter to record types
    let matchesStatus = statusFilter === 'ALL';
    if (!matchesStatus) {
      if (statusFilter === 'VACATION') matchesStatus = r.type === 'VACATION';
      else if (statusFilter === 'ABSENCE') matchesStatus = r.type === 'ABSENCE' || r.type === 'SICK_LEAVE';
      else if (statusFilter === 'REST') matchesStatus = r.type === 'REST' || r.type === 'OFF' || r.type === 'HOLIDAY';
    }

    const matchesDate = showAllHistory || r.date === startDate || (r.endDate && startDate >= r.date && startDate <= r.endDate);
    return matchesSearch && matchesStatus && matchesDate;
  }).sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  return (
    <div className="space-y-6 animate-fade-in pb-20 relative">
      <AnimatePresence>
        {showSuccessToast && (
          <motion.div 
            initial={{ opacity: 0, y: -50 }}
            animate={{ opacity: 1, y: 20 }}
            exit={{ opacity: 0, y: -50 }}
            className="fixed top-4 left-1/2 -translate-x-1/2 z-[500] bg-emerald-600 text-white px-6 py-3 rounded-2xl shadow-2xl flex items-center gap-3 font-black text-[10px] uppercase tracking-widest"
          >
            <CheckCircle2 className="w-4 h-4" />
            Registo Atualizado com Sucesso
          </motion.div>
        )}
      </AnimatePresence>

      <header className="bg-white dark:bg-slate-900 p-6 rounded-[2rem] border border-slate-100 dark:border-white/5 shadow-xl flex flex-col md:flex-row justify-between items-center gap-4">
        <div className="flex items-center gap-4">
          <div className="p-4 bg-indigo-50 dark:bg-indigo-900/20 rounded-2xl text-indigo-600">
            <Calendar className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-black uppercase tracking-tight text-slate-900 dark:text-white italic leading-none">Arquivo Master</h2>
            <p className="text-slate-400 font-bold uppercase tracking-widest text-[9px] mt-1">Registos de Assiduidade e Férias</p>
          </div>
        </div>
        <div className="flex gap-2">
          <AnimatePresence>
            {selectedRows.length > 0 && (
              <motion.button 
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.8 }}
                onClick={handleDeleteSelected} 
                className="bg-rose-600 text-white px-5 py-3 rounded-xl text-[10px] font-black uppercase shadow-lg hover:bg-rose-500 transition-all flex items-center gap-2"
              >
                <Trash2 className="w-4 h-4" />
                Eliminar ({selectedRows.length})
              </motion.button>
            )}
          </AnimatePresence>
          {activeTab === 'ABSENCES' ? (
            <button onClick={() => requestAuth(() => setIsAddAbsenceModalOpen(true))} className="bg-amber-600 text-white px-5 py-3 rounded-xl text-[10px] font-black uppercase shadow-lg hover:bg-amber-500 transition-all flex items-center gap-2">
              <Plus className="w-4 h-4" />
              Nova Ausência
            </button>
          ) : (
            <button onClick={() => requestAuth(() => setIsManualAddModalOpen(true))} className="bg-indigo-600 text-white px-5 py-3 rounded-xl text-[10px] font-black uppercase shadow-lg hover:bg-indigo-500 transition-all flex items-center gap-2">
              <Plus className="w-4 h-4" />
              Novo Registo
            </button>
          )}
        </div>
      </header>

      <div className="flex bg-white dark:bg-slate-900 p-1.5 rounded-[1.5rem] w-fit shadow-md border border-slate-100 dark:border-white/5 mx-auto">
        <button onClick={() => { setActiveTab('SUMMARY'); setStatusFilter('ALL'); setShowAllHistory(false); }} className={`px-6 py-3 rounded-[1rem] text-[9px] font-black uppercase tracking-widest transition-all ${activeTab === 'SUMMARY' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400'}`}>Resumo Diário</button>
        <button onClick={() => { setActiveTab('DETAILED'); setStatusFilter('ALL'); }} className={`px-6 py-3 rounded-[1rem] text-[9px] font-black uppercase tracking-widest transition-all ${activeTab === 'DETAILED' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400'}`}>Histórico</button>
        <button onClick={() => setActiveTab('ABSENCES')} className={`px-6 py-3 rounded-[1rem] text-[9px] font-black uppercase tracking-widest transition-all ${activeTab === 'ABSENCES' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400'}`}>Ausências</button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 bg-white dark:bg-slate-900 p-6 rounded-[2rem] border border-slate-100 dark:border-white/5 shadow-lg items-end">
        <div className="space-y-1">
          <label className="text-[8px] font-black text-slate-400 uppercase tracking-widest ml-1 flex items-center gap-1">
            <Search className="w-2 h-2" /> Pesquisar
          </label>
          <input type="text" placeholder="Nome ou código..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-950 rounded-xl text-[11px] font-bold dark:text-white outline-none border border-transparent focus:border-indigo-500 shadow-inner" />
        </div>
        <div className="space-y-1">
          <label className="text-[8px] font-black text-slate-400 uppercase tracking-widest ml-1 flex items-center gap-1">
            <Filter className="w-2 h-2" /> Estado
          </label>
          <select value={statusFilter} onChange={e => setStatusFilter(e.target.value)} className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-950 rounded-xl text-[11px] font-bold dark:text-white outline-none border border-transparent focus:border-indigo-500 shadow-inner">
            <option value="ALL">TODOS OS ESTADOS</option>
            <option value="DONE">✅ CONCLUÍDO</option>
            <option value="INCOMPLETE">⏳ EM CURSO</option>
            <option value="ABSENCE">⚠️ FALTAS</option>
            <option value="REST">🏠 DESCANSO</option>
            <option value="VACATION">🌴 FÉRIAS</option>
          </select>
        </div>
        <div className="space-y-1">
          <label className="text-[8px] font-black text-slate-400 uppercase tracking-widest ml-1 flex items-center gap-1">
            <Calendar className="w-2 h-2" /> Data de Referência
          </label>
          <input type="date" value={startDate} disabled={showAllHistory} onChange={e => setStartDate(e.target.value)} className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-950 rounded-xl text-[11px] font-bold dark:text-white outline-none border border-transparent focus:border-indigo-500 shadow-inner disabled:opacity-30" />
        </div>
        {activeTab === 'DETAILED' && (
          <button onClick={() => setShowAllHistory(!showAllHistory)} className={`w-full py-3 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all border-2 ${showAllHistory ? 'bg-indigo-600 text-white border-indigo-600' : 'text-indigo-600 border-indigo-600'}`}>
            {showAllHistory ? 'Ver Data Única' : 'Ver Todo o Histórico'}
          </button>
        )}
      </div>

      <div className="bg-white dark:bg-slate-900 rounded-[2rem] shadow-xl border border-slate-100 dark:border-white/5 overflow-hidden">
        <div className="overflow-x-auto custom-scrollbar">
          <table className="w-full text-left border-separate border-spacing-0">
            <thead className="bg-slate-50 dark:bg-slate-800/30 text-slate-400 text-[8px] font-black uppercase tracking-[0.2em]">
              <tr>
                <th className="px-4 py-5 text-center">
                  <input 
                    type="checkbox" 
                    className="w-4 h-4 rounded border-slate-300"
                    checked={activeTab === 'ABSENCES' ? (absenceRecords.length > 0 && selectedRows.length === absenceRecords.length) : (currentRows.length > 0 && selectedRows.length === currentRows.length)}
                    onChange={(e) => {
                      if (e.target.checked) {
                        const ids = activeTab === 'ABSENCES' ? absenceRecords.map(r => r.id) : currentRows.map(r => `${r.emp.id}|${r.date}`);
                        setSelectedRows(ids);
                      } else {
                        setSelectedRows([]);
                      }
                    }}
                  />
                </th>
                <th className="px-8 py-5">Data</th>
                <th className="px-8 py-5">Cód.</th>
                <th className="px-8 py-5">Colaborador</th>
                <th className="px-8 py-5 text-center">Registos Master (E/S)</th>
                <th className="px-8 py-5 text-center">Observações</th>
                <th className="px-8 py-5 text-center">Estado</th>
                <th className="px-8 py-5 text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {activeTab !== 'ABSENCES' && currentRows.map((row, idx) => {
                const rowId = `${row.emp.id}|${row.date}`;
                return (
                  <tr key={`${row.emp.id}-${row.date}-${idx}`} className={`hover:bg-slate-50 dark:hover:bg-slate-800/20 transition-all h-20 ${selectedRows.includes(rowId) ? 'bg-indigo-50/50 dark:bg-indigo-900/10' : ''}`}>
                    <td className="px-4 py-1 text-center">
                      <input 
                        type="checkbox" 
                        className="w-4 h-4 rounded border-slate-300 accent-indigo-600"
                        checked={selectedRows.includes(rowId)}
                        onChange={() => toggleRowSelection(rowId)}
                      />
                    </td>
                    <td className="px-8 py-1 font-mono text-[10px] text-slate-400 font-bold">{row.date}</td>
                    <td className="px-8 py-1 font-mono text-[10px] text-slate-400 font-bold">{row.emp.code}</td>
                    <td className="px-8 py-1 font-black uppercase text-[10px] text-slate-700 dark:text-slate-200 truncate max-w-[120px]">{row.emp.name}</td>
                  <td className="px-8 py-1 text-center min-w-[280px]">{renderPunchLine(row.dayPunches)}</td>
                  <td className="px-8 py-1 text-center truncate max-w-[150px] text-[9px] font-bold text-slate-400">{row.notes || '--'}</td>
                  <td className="px-8 py-1">
                    <span className={`px-3 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-widest border flex items-center gap-2 w-fit mx-auto shadow-sm ${row.status.color}`}>
                      {row.status.icon}
                      {row.status.label}
                    </span>
                  </td>
                  <td className="px-8 py-1 text-right">
                    {activeTab !== 'SUMMARY' && (
                      <div className="flex justify-end gap-2">
                        <button onClick={() => requestAuth(() => openEditDay(row.emp, row.date))} className="p-2 bg-slate-50 dark:bg-slate-800 hover:bg-indigo-600 hover:text-white rounded-lg text-indigo-600 transition-all shadow-sm">
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button onClick={() => requestAuth(() => { if(confirm('Apagar registos deste dia?')) onSyncDay(row.emp.id, row.date, []); })} className="p-2 bg-slate-50 dark:bg-slate-800 hover:bg-rose-600 hover:text-white rounded-lg text-rose-500 transition-all shadow-sm">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    )}
                  </td>
                </tr>
              );
            })}
            {activeTab === 'ABSENCES' && absenceRecords.map(r => {
                const emp = employees.find(e => e.id === r.employeeId);
                const status = getStatusInfo(r, r.date, 0);
                return (
                  <tr key={r.id} className={`hover:bg-slate-50 dark:hover:bg-slate-800/20 transition-all h-20 ${selectedRows.includes(r.id) ? 'bg-indigo-50/50 dark:bg-indigo-900/10' : ''}`}>
                    <td className="px-4 py-1 text-center">
                      <input 
                        type="checkbox" 
                        className="w-4 h-4 rounded border-slate-300 accent-indigo-600"
                        checked={selectedRows.includes(r.id)}
                        onChange={() => toggleRowSelection(r.id)}
                      />
                    </td>
                    <td className="px-8 py-1 font-mono text-[10px] font-black text-slate-400">
                      <div className="flex flex-col">
                        <span>{r.date}</span>
                        {r.endDate && <span className="text-[8px] opacity-50">até {r.endDate}</span>}
                      </div>
                    </td>
                    <td className="px-8 py-1 font-mono text-[10px] font-black text-slate-400">{emp?.code || '---'}</td>
                    <td className="px-8 py-1 font-black uppercase text-[10px] text-slate-700 dark:text-slate-200">{emp?.name || '---'}</td>
                    <td className="px-8 py-1 text-center">
                      <div className="flex items-center justify-center gap-2 text-[9px] text-slate-300 italic uppercase font-black">
                        <Lock className="w-3 h-3" />
                        Registo Permanente
                      </div>
                    </td>
                    <td className="px-8 py-1 text-center truncate max-w-[150px] text-[9px] font-bold text-slate-400">{r.reason || '--'}</td>
                    <td className="px-8 py-1">
                      <span className={`px-3 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-widest border flex items-center gap-2 w-fit mx-auto shadow-sm ${status.color}`}>
                        {status.icon}
                        {status.label}
                      </span>
                    </td>
                    <td className="px-8 py-1 text-right">
                       <div className="flex justify-end gap-2">
                         <button onClick={() => requestAuth(() => openEditVacation(r))} className="p-2 bg-slate-50 dark:bg-slate-800 hover:bg-indigo-600 hover:text-white rounded-lg text-indigo-600 transition-all shadow-sm">
                            <Edit2 className="w-4 h-4" />
                         </button>
                         <button onClick={() => requestAuth(() => onDeleteRecord(r.id))} className="p-2 bg-slate-50 dark:bg-slate-800 hover:bg-rose-600 hover:text-white rounded-lg text-rose-500 transition-all shadow-sm">
                            <Trash2 className="w-4 h-4" />
                         </button>
                       </div>
                    </td>
                  </tr>
                );
              })}
              {activeTab === 'ABSENCES' && absenceRecords.length === 0 && (
                <tr>
                  <td colSpan={8} className="py-20 text-center">
                    <div className="flex flex-col items-center gap-4 opacity-20">
                      <Calendar className="w-16 h-16" />
                      <p className="text-xs font-black uppercase tracking-widest">Nenhuma ausência registada para este filtro</p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Absence Modal */}
      <AnimatePresence>
        {isAddAbsenceModalOpen && (
          <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-[200] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="bg-white dark:bg-slate-900 rounded-[2.5rem] shadow-2xl max-w-lg w-full p-10 border dark:border-white/5"
            >
              <div className="flex justify-between items-center mb-8">
                <div className="flex items-center gap-3">
                  <div className="p-3 bg-amber-50 dark:bg-amber-900/20 rounded-2xl text-amber-600">
                    <Plus className="w-5 h-5" />
                  </div>
                  <h3 className="text-xl font-black uppercase text-slate-900 dark:text-white italic">Nova Ausência</h3>
                </div>
                <button onClick={() => setIsAddAbsenceModalOpen(false)} className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full transition-all">
                  <X className="w-5 h-5 text-slate-400" />
                </button>
              </div>

              <form onSubmit={handleAddAbsenceSubmit} className="space-y-6">
                <div className="space-y-1">
                  <label className="text-[8px] font-black text-slate-400 uppercase tracking-widest ml-1">Colaborador</label>
                  <select name="employeeId" required className="w-full px-4 py-4 bg-slate-50 dark:bg-slate-950 rounded-2xl text-[11px] font-bold dark:text-white outline-none border-2 border-transparent focus:border-indigo-600 transition-all">
                    {employees.map(e => <option key={e.id} value={e.id}>{e.name} ({e.code})</option>)}
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-[8px] font-black text-slate-400 uppercase tracking-widest ml-1">Tipo de Ausência</label>
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      { val: 'VACATION', label: 'FÉRIAS', icon: '🌴' },
                      { val: 'ABSENCE', label: 'FALTA', icon: '⚠️' },
                      { val: 'SICK_LEAVE', label: 'BAIXA', icon: '🤒' },
                      { val: 'OFF', label: 'FOLGA', icon: '🏠' },
                      { val: 'HOLIDAY', label: 'FERIADO', icon: '🎉' },
                      { val: 'REST', label: 'DESCANSO', icon: '🏠' }
                    ].map(opt => (
                      <label key={opt.val} className="relative cursor-pointer group">
                        <input type="radio" name="type" value={opt.val} required className="peer sr-only" defaultChecked={opt.val === 'VACATION'} />
                        <div className="p-3 bg-slate-50 dark:bg-slate-950 rounded-xl border-2 border-transparent peer-checked:border-indigo-600 peer-checked:bg-indigo-50 dark:peer-checked:bg-indigo-900/20 transition-all flex items-center gap-2">
                          <span className="text-sm">{opt.icon}</span>
                          <span className="text-[9px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400 peer-checked:text-indigo-600">{opt.label}</span>
                        </div>
                      </label>
                    ))}
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-[8px] font-black text-slate-400 uppercase tracking-widest ml-1">Início</label>
                    <input type="date" name="date" required defaultValue={startDate} className="w-full px-4 py-4 bg-slate-50 dark:bg-slate-950 rounded-2xl text-[11px] font-bold dark:text-white outline-none border-2 border-transparent focus:border-indigo-600 transition-all" />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[8px] font-black text-slate-400 uppercase tracking-widest ml-1">Fim (Opcional)</label>
                    <input type="date" name="endDate" className="w-full px-4 py-4 bg-slate-50 dark:bg-slate-950 rounded-2xl text-[11px] font-bold dark:text-white outline-none border-2 border-transparent focus:border-indigo-600 transition-all" />
                  </div>
                </div>
                <div className="space-y-1">
                  <label className="text-[8px] font-black text-slate-400 uppercase tracking-widest ml-1">Observações</label>
                  <textarea name="reason" placeholder="Motivo detalhado..." className="w-full px-4 py-4 bg-slate-50 dark:bg-slate-950 rounded-2xl text-[11px] font-bold dark:text-white h-24 resize-none outline-none border-2 border-transparent focus:border-indigo-600 transition-all shadow-inner" />
                </div>
                <div className="flex gap-3 pt-4">
                  <button type="button" onClick={() => setIsAddAbsenceModalOpen(false)} className="flex-1 py-4 text-[10px] font-black uppercase text-slate-400 hover:text-slate-600 transition-all">Cancelar</button>
                  <button type="submit" className="flex-[2] bg-indigo-600 text-white py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-xl hover:bg-indigo-700 transition-all flex items-center justify-center gap-2">
                    <CheckCircle2 className="w-4 h-4" />
                    Confirmar Registo
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Manual Add Modal */}
      {isManualAddModalOpen && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-[200] flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-[2rem] shadow-2xl max-w-lg w-full p-8 animate-slide-up border dark:border-white/5">
            <h3 className="text-xl font-black uppercase mb-6 text-slate-900 dark:text-white italic text-center">Registo Master</h3>
            <form onSubmit={handleManualAddSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-[8px] font-black text-slate-400 uppercase tracking-widest ml-1">Colaborador</label>
                  <select name="employeeId" required className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-950 rounded-xl text-[11px] font-bold dark:text-white outline-none border border-transparent focus:border-indigo-600">
                    {employees.map(e => <option key={e.id} value={e.id}>{e.name}</option>)}
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-[8px] font-black text-slate-400 uppercase tracking-widest ml-1">Data</label>
                  <input type="date" name="date" required defaultValue={startDate} className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-950 rounded-xl text-[11px] font-bold dark:text-white border border-transparent focus:border-indigo-600 outline-none" />
                </div>
              </div>
              <div className="grid grid-cols-4 gap-2">
                {['e1', 's1', 'e2', 's2'].map(field => (
                  <div key={field} className="space-y-1">
                    <label className="text-[8px] font-black text-slate-400 uppercase tracking-widest ml-1">{field.toUpperCase()}</label>
                    <input type="time" name={field} className="w-full px-2 py-3 bg-slate-50 dark:bg-slate-950 rounded-xl text-[11px] font-bold dark:text-white border border-transparent focus:border-indigo-600 outline-none shadow-inner" />
                  </div>
                ))}
              </div>
              <div className="space-y-1">
                <label className="text-[8px] font-black text-slate-400 uppercase tracking-widest ml-1">Observações</label>
                <textarea name="notes" placeholder="Descreva as ocorrências..." className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-950 rounded-xl text-[11px] font-bold dark:text-white h-20 resize-none outline-none border border-transparent focus:border-indigo-600 shadow-inner" />
              </div>
              <div className="flex gap-3 pt-4">
                <button type="button" onClick={() => setIsManualAddModalOpen(false)} className="flex-1 py-3 text-[10px] font-black uppercase text-slate-400">Cancelar</button>
                <button type="submit" className="flex-[2] bg-indigo-600 text-white py-3 rounded-xl text-[10px] font-black uppercase tracking-widest shadow-xl">Guardar</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Day Modal */}
      {isEditDayModalOpen && editDayData && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-[200] flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-[2rem] shadow-2xl max-w-lg w-full p-8 animate-slide-up border dark:border-white/5">
            <h3 className="text-xl font-black uppercase mb-2 text-slate-900 dark:text-white italic text-center">Editar Dia Master</h3>
            <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest mb-6 text-center">{editDayData.emp.name} | {editDayData.date}</p>
            <form onSubmit={handleEditDaySubmit} className="space-y-6">
              <div className="grid grid-cols-4 gap-2">
                {['e1', 's1', 'e2', 's2'].map(field => (
                  <div key={field} className="space-y-1">
                    <label className="text-[8px] font-black text-slate-400 uppercase tracking-widest ml-1">{field.toUpperCase()}</label>
                    <input type="time" name={field} defaultValue={(editDayData as any)[field]} className="w-full px-2 py-3 bg-slate-50 dark:bg-slate-950 rounded-xl text-[11px] font-bold dark:text-white border border-transparent focus:border-indigo-600 outline-none shadow-inner" />
                  </div>
                ))}
              </div>
              <div className="space-y-1">
                <label className="text-[8px] font-black text-slate-400 uppercase tracking-widest ml-1">Observações</label>
                <textarea name="notes" defaultValue={editDayData.notes} placeholder="Notas de auditoria..." className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-950 rounded-xl text-[11px] font-bold dark:text-white h-20 resize-none outline-none border border-transparent focus:border-indigo-600 shadow-inner" />
              </div>
              <div className="flex gap-3 pt-4">
                <button type="button" onClick={() => setIsEditDayModalOpen(false)} className="flex-1 py-3 text-[10px] font-black uppercase text-slate-400">Descartar</button>
                <button type="submit" className="flex-[2] bg-indigo-600 text-white py-3 rounded-xl text-[10px] font-black uppercase tracking-widest shadow-xl">Sincronizar</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Vacation Modal */}
      <AnimatePresence>
        {isEditVacationModalOpen && editVacationData && (
          <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-[200] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="bg-white dark:bg-slate-900 rounded-[2.5rem] shadow-2xl max-w-lg w-full p-10 border dark:border-white/5"
            >
              <div className="flex justify-between items-center mb-8">
                <div className="flex items-center gap-3">
                  <div className="p-3 bg-indigo-50 dark:bg-indigo-900/20 rounded-2xl text-indigo-600">
                    <Edit2 className="w-5 h-5" />
                  </div>
                  <h3 className="text-xl font-black uppercase text-slate-900 dark:text-white italic">Editar Ausência</h3>
                </div>
                <button onClick={() => setIsEditVacationModalOpen(false)} className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full transition-all">
                  <X className="w-5 h-5 text-slate-400" />
                </button>
              </div>

              <form onSubmit={handleEditVacationSubmit} className="space-y-6">
                <div className="space-y-1">
                  <label className="text-[8px] font-black text-slate-400 uppercase tracking-widest ml-1">Tipo de Ausência</label>
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      { val: 'VACATION', label: 'FÉRIAS', icon: '🌴' },
                      { val: 'ABSENCE', label: 'FALTA', icon: '⚠️' },
                      { val: 'SICK_LEAVE', label: 'BAIXA', icon: '🤒' },
                      { val: 'OFF', label: 'FOLGA', icon: '🏠' },
                      { val: 'HOLIDAY', label: 'FERIADO', icon: '🎉' },
                      { val: 'REST', label: 'DESCANSO', icon: '🏠' }
                    ].map(opt => (
                      <label key={opt.val} className="relative cursor-pointer group">
                        <input type="radio" name="type" value={opt.val} required className="peer sr-only" defaultChecked={editVacationData.type === opt.val} />
                        <div className="p-3 bg-slate-50 dark:bg-slate-950 rounded-xl border-2 border-transparent peer-checked:border-indigo-600 peer-checked:bg-indigo-50 dark:peer-checked:bg-indigo-900/20 transition-all flex items-center gap-2">
                          <span className="text-sm">{opt.icon}</span>
                          <span className="text-[9px] font-black uppercase tracking-widest text-slate-500 dark:text-slate-400 peer-checked:text-indigo-600">{opt.label}</span>
                        </div>
                      </label>
                    ))}
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-[8px] font-black text-slate-400 uppercase tracking-widest ml-1">Início</label>
                    <input type="date" name="date" required defaultValue={editVacationData.date} className="w-full px-4 py-4 bg-slate-50 dark:bg-slate-950 rounded-2xl text-[11px] font-bold dark:text-white outline-none border-2 border-transparent focus:border-indigo-600 transition-all" />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[8px] font-black text-slate-400 uppercase tracking-widest ml-1">Fim</label>
                    <input type="date" name="endDate" required defaultValue={editVacationData.endDate} className="w-full px-4 py-4 bg-slate-50 dark:bg-slate-950 rounded-2xl text-[11px] font-bold dark:text-white outline-none border-2 border-transparent focus:border-indigo-600 transition-all" />
                  </div>
                </div>
                <div className="space-y-1">
                  <label className="text-[8px] font-black text-slate-400 uppercase tracking-widest ml-1">Observações</label>
                  <textarea name="reason" defaultValue={editVacationData.reason} placeholder="Motivo..." className="w-full px-4 py-4 bg-slate-50 dark:bg-slate-950 rounded-2xl text-[11px] font-bold dark:text-white h-24 resize-none outline-none border-2 border-transparent focus:border-indigo-600 transition-all shadow-inner" />
                </div>
                <div className="flex gap-3 pt-4">
                  <button type="button" onClick={() => setIsEditVacationModalOpen(false)} className="flex-1 py-4 text-[10px] font-black uppercase text-slate-400 hover:text-slate-600 transition-all">Voltar</button>
                  <button type="submit" className="flex-[2] bg-indigo-600 text-white py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-xl hover:bg-indigo-700 transition-all flex items-center justify-center gap-2">
                    <CheckCircle2 className="w-4 h-4" />
                    Guardar Alterações
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* PIN Auth Modal */}
      <AnimatePresence>
        {isPinModalOpen && (
          <div className="fixed inset-0 bg-slate-950/95 backdrop-blur-2xl z-[300] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 50 }}
              className="bg-white dark:bg-slate-900 rounded-[3rem] shadow-2xl w-full max-w-sm p-12 text-center border dark:border-white/5"
            >
              <div className="flex flex-col items-center gap-4 mb-8">
                <div className="p-4 bg-indigo-50 dark:bg-indigo-900/20 rounded-full text-indigo-600">
                  <Lock className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-black text-slate-900 dark:text-white uppercase italic">Acesso Admin</h3>
                <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Insira o PIN para prosseguir</p>
              </div>
              <form onSubmit={handlePinSubmit} className="space-y-8">
                <input type="password" value={pinValue} onChange={e => setPinValue(e.target.value.replace(/\D/g, '').slice(0, 4))} placeholder="••••" className="w-full bg-slate-50 dark:bg-slate-950 p-6 rounded-2xl text-center text-5xl font-mono tracking-[0.5em] outline-none border-2 border-transparent focus:border-indigo-600 dark:text-white shadow-inner" autoFocus />
                <div className="flex gap-4">
                  <button type="button" onClick={() => setIsPinModalOpen(false)} className="flex-1 text-[11px] font-black uppercase text-slate-400 py-4 hover:text-slate-600 transition-all">Voltar</button>
                  <button type="submit" className="flex-[2] bg-indigo-600 text-white py-4 rounded-xl font-black text-xs uppercase shadow-xl hover:bg-indigo-700 transition-all">Validar</button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default HistoryView;
