
import React, { useState, useMemo } from 'react';
import { EmailConfig, Employee, Punch, LocationConfig, AbsenceRecord, PunchType, EntryMethod, EntryModality } from '../types';
import { StorageService } from '../services/storage';

interface SettingsViewProps {
  emailConfig: EmailConfig;
  onSaveEmailConfig: (config: EmailConfig) => void;
  onImportData: (data: { employees: Employee[], punches: Punch[], records: AbsenceRecord[] }) => void;
  employees: Employee[];
  punches: Punch[];
  records: AbsenceRecord[];
  onClearPunches: () => void;
  onDeletePunch: (id: string) => void;
  onDeleteRecord: (id: string) => void;
  onDeleteRecords: (ids: string[]) => void;
  onSyncDay: (empId: string, date: string, newPunches: Punch[], newRecord?: AbsenceRecord) => void;
  onClearAll: () => void;
}

type ReportType = 'DAY' | 'WEEK' | 'MONTH' | 'YEAR';

const SettingsView: React.FC<SettingsViewProps> = ({ 
  emailConfig, onSaveEmailConfig, onImportData, 
  employees, punches, records,
  onClearPunches, onDeletePunch, onDeleteRecord, onDeleteRecords, onSyncDay, onClearAll
}) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [pinInput, setPinInput] = useState('');
  const [localEmailConfig, setLocalEmailConfig] = useState<EmailConfig>(emailConfig);
  const [localLocationConfig, setLocalLocationConfig] = useState<LocationConfig>(StorageService.getLocationConfig());
  
  const [reportType, setReportType] = useState<ReportType>('MONTH');
  const [reportDate, setReportDate] = useState(new Date().toISOString().split('T')[0]);
  const [reportMonth, setReportMonth] = useState(new Date().toISOString().slice(0, 7));
  const [reportYear, setReportYear] = useState(new Date().getFullYear().toString());

  const [isSaved, setIsSaved] = useState(false);
  const [showClearModal, setShowClearModal] = useState(false);
  const [showClearAllModal, setShowClearAllModal] = useState(false);
  
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [selectedRows, setSelectedRows] = useState<string[]>([]);
  const [editDayData, setEditDayData] = useState<{ 
    emp: Employee, 
    date: string, 
    e1: string, s1: string, e2: string, s2: string, 
    notes: string 
  } | null>(null);

  const openEditDay = (item: any) => {
    const emp = employees.find(e => e.id === item.empId);
    if (!emp) return;
    const dayPunches = punches.filter(p => p.employeeId === emp.id && p.timestamp.startsWith(item.date)).sort((a,b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
    const getT = (idx: number) => {
      if (!dayPunches[idx]) return '';
      const d = new Date(dayPunches[idx].timestamp);
      return d.toLocaleTimeString('pt-PT', {hour:'2-digit', minute:'2-digit', timeZone: 'UTC'});
    };
    setEditDayData({
      emp, date: item.date, e1: getT(0), s1: getT(1), e2: getT(2), s2: getT(3),
      notes: Array.from(new Set(dayPunches.map(p => p.notes).filter(Boolean))).join(' | ')
    });
  };

  const handleEditDaySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editDayData) return;
    const newPunches: Punch[] = [];
    const times = [editDayData.e1, editDayData.s1, editDayData.e2, editDayData.s2];
    times.forEach((t, i) => {
      if (t && t.trim() !== "") {
        newPunches.push({
          id: Math.random().toString(36).substr(2, 9),
          employeeId: editDayData.emp.id,
          timestamp: `${editDayData.date}T${t}:00.000Z`,
          type: i % 2 === 0 ? PunchType.IN : PunchType.OUT,
          entryMethod: EntryMethod.MANUAL,
          modality: EntryModality.PIN,
          notes: editDayData.notes
        });
      }
    });
    onSyncDay(editDayData.emp.id, editDayData.date, newPunches);
    setEditDayData(null);
  };

  const handleAuth = (e: React.FormEvent) => {
    e.preventDefault();
    if (pinInput === '2303') {
      setIsAuthenticated(true);
      setPinInput('');
    } else {
      alert('PIN Incorreto!');
      setPinInput('');
    }
  };

  const toggleRowSelection = (id: string) => {
    setSelectedRows(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);
  };

  const handleDeleteSelected = () => {
    if (selectedRows.length === 0) return;
    if (confirm(`Deseja apagar os ${selectedRows.length} registos selecionados?`)) {
      selectedRows.forEach(id => {
        const [empId, date] = id.split('|');
        onSyncDay(empId, date, []);
      });
      setSelectedRows([]);
    }
  };

  const handleSave = () => {
    onSaveEmailConfig(localEmailConfig);
    StorageService.saveLocationConfig(localLocationConfig);
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 3000);
  };

  const formatH = (h: number) => {
    const totalMinutes = Math.round(h * 60);
    const hours = Math.floor(Math.abs(totalMinutes) / 60);
    const minutes = Math.abs(totalMinutes) % 60;
    const sign = h < 0 ? '-' : '';
    return `${sign}${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
  };

  const reportRange = useMemo(() => {
    let start = '';
    let end = '';
    
    if (reportType === 'DAY') {
      start = reportDate;
      end = reportDate;
    } else if (reportType === 'WEEK') {
      const d = new Date(reportDate);
      const day = d.getDay();
      const diff = d.getDate() - day + (day === 0 ? -6 : 1);
      const monday = new Date(d.setDate(diff));
      const sunday = new Date(monday);
      sunday.setDate(monday.getDate() + 6);
      start = monday.toISOString().split('T')[0];
      end = sunday.toISOString().split('T')[0];
    } else if (reportType === 'MONTH') {
      const [y, m] = reportMonth.split('-').map(Number);
      start = `${y}-${m.toString().padStart(2, '0')}-01`;
      end = new Date(y, m, 0).toISOString().split('T')[0];
    } else if (reportType === 'YEAR') {
      start = `${reportYear}-01-01`;
      end = `${reportYear}-12-31`;
    }

    return { start, end };
  }, [reportType, reportDate, reportMonth, reportYear]);

  const summaryData = useMemo(() => {
    const { start, end } = reportRange;
    if (!start || !end) return [];
    
    const startDate = new Date(start);
    const endDate = new Date(end);
    const result: any[] = [];

    employees.forEach(emp => {
      let current = new Date(startDate);
      while (current <= endDate) {
        const dateStr = current.toISOString().split('T')[0];
        const dayPunches = punches.filter(p => p.employeeId === emp.id && p.timestamp.startsWith(dateStr))
          .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
        
        const ins = dayPunches.filter(p => p.type === PunchType.IN);
        const outs = dayPunches.filter(p => p.type === PunchType.OUT);
        
        const dayRecord = records.find(r => r.employeeId === emp.id && (dateStr === r.date || (r.endDate && dateStr >= r.date && dateStr <= r.endDate)));
        
        const dayOfWeek = current.getDay();
        const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;

        let workedHours = 0;
        const numIntervals = Math.min(ins.length, outs.length);
        for (let i = 0; i < numIntervals; i++) {
            const diffMs = new Date(outs[i].timestamp).getTime() - new Date(ins[i].timestamp).getTime();
            if (diffMs > 0) workedHours += diffMs / (1000 * 60 * 60);
        }

        let isNonWorkDay = isWeekend || (dayRecord && (dayRecord.type === 'VACATION' || dayRecord.type === 'REST' || dayRecord.type === 'OFF' || dayRecord.type === 'HOLIDAY' || dayRecord.type.startsWith('HOLIDAY')));
        let target = isNonWorkDay ? 0 : (emp.dailyWorkHours || 8);
        
        let status = "PRESENTE";
        let observations = "";
        
        if (dayRecord) {
            switch(dayRecord.type) {
                case 'VACATION': status = "FÉRIAS"; break;
                case 'ABSENCE': status = "FALTA"; break;
                case 'SICK_LEAVE': status = "BAIXA"; break;
                case 'OFF': status = "FOLGA"; break;
                case 'HOLIDAY': status = "FERIADO"; break;
                case 'REST': status = "DESCANSO"; break;
                default: status = "AUSENTE";
            }
            observations = dayRecord.reason || "";
        } else if (dayPunches.length === 0 && !isWeekend) {
            status = "FALTA";
        } else if (dayPunches.length % 2 !== 0) {
            status = "INCOMPLETO";
        } else if (isWeekend && dayPunches.length === 0) {
            status = "DESCANSO";
        }

        const punchNotes = Array.from(new Set(dayPunches.map(p => p.notes).filter(Boolean))).join(' | ');
        if (punchNotes) observations = observations ? `${observations} | ${punchNotes}` : punchNotes;

        result.push({
          empId: emp.id,
          empCode: emp.code,
          date: dateStr,
          name: emp.name,
          status: status,
          entrada: ins.map(p => new Date(p.timestamp).toLocaleTimeString('pt-PT', {hour:'2-digit', minute:'2-digit', timeZone: 'UTC'})).join(' | '),
          saida: outs.map(p => new Date(p.timestamp).toLocaleTimeString('pt-PT', {hour:'2-digit', minute:'2-digit', timeZone: 'UTC'})).join(' | '),
          worked: workedHours,
          balance: workedHours - target,
          observations: observations
        });

        current.setDate(current.getDate() + 1);
      }
    });

    return result.filter(item => {
      const matchesSearch = !searchTerm || (
        item.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
        item.empCode.includes(searchTerm)
      );
      const matchesStatus = statusFilter === 'ALL' || item.status === statusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [reportRange, employees, punches, records, searchTerm, statusFilter]);

  const exportToExcel = () => {
    const headers = ['Data', 'Cód.', 'Colaborador', 'Estado', 'Entradas', 'Saídas', 'Horas', 'Saldo', 'Observações'];
    const rows = summaryData.map(item => [
      item.date,
      item.empCode,
      item.name,
      item.status,
      item.entrada,
      item.saida,
      formatH(item.worked),
      formatH(item.balance),
      item.observations
    ]);
    const csvContent = [headers, ...rows].map(e => e.join(";")).join("\n");
    const blob = new Blob(["\ufeff" + csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = `Relatorio_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
  };

  return (
    <div className="max-w-6xl mx-auto space-y-10 animate-fade-in pb-32">
      {!isAuthenticated ? (
        <div className="flex flex-col items-center justify-center min-h-[60vh]">
          <form onSubmit={handleAuth} className="bg-white dark:bg-slate-900 p-12 rounded-[3rem] shadow-2xl border border-slate-100 dark:border-white/5 text-center space-y-6 w-full max-w-sm">
            <h2 className="text-xl font-black uppercase text-slate-800 dark:text-white tracking-tighter italic">Painel Admin</h2>
            <input type="password" value={pinInput} onChange={e => setPinInput(e.target.value.replace(/\D/g, '').slice(0, 4))} placeholder="••••" className="w-full bg-slate-50 dark:bg-slate-950 p-6 rounded-3xl text-center text-5xl font-mono outline-none border-2 border-transparent focus:border-indigo-600 dark:text-white shadow-inner" autoFocus />
            <button type="submit" className="w-full bg-indigo-600 text-white py-5 rounded-2xl font-black text-xs uppercase shadow-xl hover:opacity-90">Entrar</button>
          </form>
        </div>
      ) : (
        <>
          <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-white dark:bg-slate-900 p-8 rounded-[2.5rem] border border-slate-100 dark:border-white/5 shadow-sm">
            <div>
              <h2 className="text-3xl font-black text-slate-900 dark:text-white uppercase tracking-tighter italic leading-none">Relatórios</h2>
              <p className="text-slate-500 font-bold uppercase tracking-widest text-[10px] mt-2">Extração e auditoria financeira</p>
            </div>
            <button onClick={exportToExcel} className="flex items-center gap-2 bg-emerald-600 text-white px-8 py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-lg hover:bg-emerald-700 transition-all">
                Exportar CSV
            </button>
          </header>

          <div className="bg-white dark:bg-slate-900 p-10 rounded-[3rem] border border-slate-100 dark:border-white/5 shadow-sm space-y-10">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="space-y-1">
                <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-1">Modalidade</label>
                <select value={reportType} onChange={e => setReportType(e.target.value as ReportType)} className="w-full px-5 py-4 bg-slate-50 dark:bg-slate-950 border-2 border-slate-100 dark:border-slate-800 rounded-2xl outline-none text-xs font-bold dark:text-white shadow-inner">
                  <option value="DAY">Diário</option>
                  <option value="WEEK">Semanal</option>
                  <option value="MONTH">Mensal</option>
                  <option value="YEAR">Anual</option>
                </select>
              </div>
              <div className="md:col-span-2 space-y-1">
                <label className="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-1">Referência</label>
                {reportType === 'MONTH' ? (
                  <input type="month" value={reportMonth} onChange={e => setReportMonth(e.target.value)} className="w-full px-5 py-4 bg-slate-50 dark:bg-slate-950 border-2 border-slate-100 dark:border-slate-800 rounded-2xl text-xs font-bold dark:text-white shadow-inner" />
                ) : reportType === 'YEAR' ? (
                  <input type="number" value={reportYear} onChange={e => setReportYear(e.target.value)} className="w-full px-5 py-4 bg-slate-50 dark:bg-slate-950 border-2 border-slate-100 dark:border-slate-800 rounded-2xl text-xs font-bold dark:text-white shadow-inner" />
                ) : (
                  <input type="date" value={reportDate} onChange={e => setReportDate(e.target.value)} className="w-full px-5 py-4 bg-slate-50 dark:bg-slate-950 border-2 border-slate-100 dark:border-slate-800 rounded-2xl text-xs font-bold dark:text-white shadow-inner" />
                )}
              </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-[8px] font-black text-slate-400 uppercase tracking-widest ml-1">Pesquisar Colaborador / Código</label>
                <input type="text" value={searchTerm} onChange={e => setSearchTerm(e.target.value)} placeholder="Nome ou Código..." className="w-full px-5 py-4 bg-slate-50 dark:bg-slate-950 border-2 border-slate-100 dark:border-slate-800 rounded-2xl text-xs font-bold dark:text-white shadow-inner outline-none focus:border-indigo-600 transition-all" />
              </div>
              <div className="space-y-1">
                <label className="text-[8px] font-black text-slate-400 uppercase tracking-widest ml-1">Filtrar por Estado</label>
                <select value={statusFilter} onChange={e => setStatusFilter(e.target.value)} className="w-full px-5 py-4 bg-slate-50 dark:bg-slate-950 border-2 border-slate-100 dark:border-slate-800 rounded-2xl text-xs font-bold dark:text-white shadow-inner outline-none focus:border-indigo-600 transition-all">
                  <option value="ALL">TODOS OS ESTADOS</option>
                  <option value="PRESENTE">✅ PRESENTE</option>
                  <option value="FALTA">⚠️ FALTA</option>
                  <option value="FÉRIAS">🌴 FÉRIAS</option>
                  <option value="BAIXA">🤒 BAIXA</option>
                  <option value="INCOMPLETO">⏳ INCOMPLETO</option>
                  <option value="DESCANSO">🏠 DESCANSO</option>
                </select>
              </div>
            </div>

            <div className="flex justify-between items-center">
              <div className="bg-indigo-50 dark:bg-indigo-900/20 p-6 rounded-2xl border border-indigo-100 dark:border-indigo-800 flex flex-col items-center justify-center">
                   <p className="text-[8px] font-black text-indigo-400 uppercase mb-1">Total de Linhas</p>
                   <p className="text-2xl font-black text-indigo-600 dark:text-indigo-400">{summaryData.length}</p>
              </div>
              {selectedRows.length > 0 && (
                <button onClick={handleDeleteSelected} className="bg-rose-600 text-white px-8 py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-lg hover:bg-rose-500 transition-all flex items-center gap-2 animate-fade-in">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                  Eliminar Selecionados ({selectedRows.length})
                </button>
              )}
            </div>
            </div>

            <div className="overflow-x-auto rounded-[2rem] border border-slate-50 dark:border-white/5 custom-scrollbar">
              <table className="w-full text-left">
                <thead className="text-[9px] font-black uppercase text-slate-400 bg-slate-50 dark:bg-slate-800/50">
                  <tr>
                    <th className="p-6 text-center">
                      <input 
                        type="checkbox" 
                        className="w-4 h-4 rounded border-slate-300"
                        checked={summaryData.length > 0 && selectedRows.length === summaryData.length}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setSelectedRows(summaryData.map(item => `${item.empId}|${item.date}`));
                          } else {
                            setSelectedRows([]);
                          }
                        }}
                      />
                    </th>
                    <th className="p-6">Data</th>
                    <th className="p-6">Cód.</th>
                    <th className="p-6">Colaborador</th>
                    <th className="p-6">Estado</th>
                    <th className="p-6 text-center">Entradas</th>
                    <th className="p-6 text-center">Saídas</th>
                    <th className="p-6 text-center">Obs.</th>
                    <th className="p-6 text-right">Saldo</th>
                    <th className="p-6 text-right">Ação</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {summaryData.slice(0, 100).map((item, idx) => {
                    const rowId = `${item.empId}|${item.date}`;
                    return (
                      <tr key={idx} className={`text-[10px] font-bold hover:bg-slate-50 dark:hover:bg-slate-800/20 transition-colors ${selectedRows.includes(rowId) ? 'bg-indigo-50/50 dark:bg-indigo-900/10' : ''}`}>
                        <td className="p-6 text-center">
                          <input 
                            type="checkbox" 
                            className="w-4 h-4 rounded border-slate-300"
                            checked={selectedRows.includes(rowId)}
                            onChange={() => toggleRowSelection(rowId)}
                          />
                        </td>
                        <td className="p-6 font-mono text-slate-400">{item.date}</td>
                        <td className="p-6 font-mono text-slate-400">{item.empCode}</td>
                        <td className="p-6 uppercase text-slate-700 dark:text-slate-200">{item.name}</td>
                        <td className="p-6"><span className="px-3 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-950 text-[8px] font-black uppercase">{item.status}</span></td>
                        <td className="p-6 text-center font-mono">{item.entrada}</td>
                        <td className="p-6 text-center font-mono">{item.saida}</td>
                        <td className="p-6 text-center truncate max-w-[100px] text-slate-400 italic">{item.observations || '--'}</td>
                        <td className={`p-6 text-right font-mono font-black ${item.balance >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>{item.balance > 0 ? '+' : ''}{formatH(item.balance)}</td>
                        <td className="p-6 text-right">
                          <div className="flex justify-end gap-2">
                            <button onClick={() => openEditDay(item)} className="p-2 text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 rounded-lg transition-all">
                              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" /></svg>
                            </button>
                            <button onClick={() => { if(confirm('Apagar registos deste dia?')) onSyncDay(item.empId, item.date, []); }} className="p-2 text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-900/20 rounded-lg transition-all">
                              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          <div className="max-w-2xl">
            <div className="bg-white dark:bg-slate-900 p-10 rounded-[3rem] border border-slate-100 dark:border-white/5 shadow-sm space-y-6">
              <h3 className="font-black uppercase text-xs tracking-widest text-slate-800 dark:text-white italic">Configuração de Sistema</h3>
              <div className="p-4 bg-slate-50 dark:bg-slate-950 rounded-2xl border border-slate-100 dark:border-slate-800">
                <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest leading-relaxed">
                  O sistema permite acesso global sem restrições de distância. 
                  A localização GPS é registada automaticamente em cada picagem para fins de auditoria.
                </p>
              </div>
              <div className="space-y-4">
                <input type="email" value={localEmailConfig.targetEmail} onChange={e => setLocalEmailConfig({...localEmailConfig, targetEmail: e.target.value})} placeholder="Email de Destino" className="w-full bg-slate-50 dark:bg-slate-950 p-5 rounded-2xl text-xs font-bold dark:text-white outline-none border-2 border-transparent focus:border-indigo-600 transition-all shadow-inner" />
                <div className="flex items-center gap-3">
                   <input type="checkbox" checked={localEmailConfig.enabled} onChange={e => setLocalEmailConfig({...localEmailConfig, enabled: e.target.checked})} className="w-6 h-6 rounded-lg text-indigo-600" />
                   <label className="text-[10px] font-black text-slate-600 dark:text-slate-400 uppercase tracking-widest">Backup Automático Ativo</label>
                </div>
              </div>
              <div className="flex gap-3">
                <button onClick={() => setShowClearModal(true)} className="flex-1 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-rose-50 hover:text-rose-600 transition-all">Limpar Picagens</button>
                <button onClick={() => setShowClearAllModal(true)} className="flex-1 bg-rose-50 dark:bg-rose-900/20 text-rose-600 py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-rose-600 hover:text-white transition-all">Limpeza Total</button>
              </div>
              <button onClick={handleSave} className={`w-full py-5 rounded-2xl font-black text-xs uppercase tracking-widest transition-all ${isSaved ? 'bg-emerald-600 text-white' : 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/20'}`}>
                {isSaved ? 'Configurações Guardadas' : 'Gravar Alterações'}
              </button>
            </div>
          </div>

          {editDayData && (
            <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-[200] flex items-center justify-center p-4">
              <div className="bg-white dark:bg-slate-900 rounded-[2rem] shadow-2xl max-w-lg w-full p-8 animate-slide-up border dark:border-white/5">
                <h3 className="text-xl font-black uppercase mb-2 text-slate-900 dark:text-white italic text-center">Editar Registos</h3>
                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest text-center mb-8">{editDayData.emp.name} - {editDayData.date}</p>
                
                <form onSubmit={handleEditDaySubmit} className="space-y-6">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="text-[8px] font-black text-slate-400 uppercase tracking-widest ml-1">Entrada 1</label>
                      <input type="time" value={editDayData.e1} onChange={e => setEditDayData({...editDayData, e1: e.target.value})} className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-950 rounded-xl text-[11px] font-bold dark:text-white outline-none border border-transparent focus:border-indigo-600" />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[8px] font-black text-slate-400 uppercase tracking-widest ml-1">Saída 1</label>
                      <input type="time" value={editDayData.s1} onChange={e => setEditDayData({...editDayData, s1: e.target.value})} className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-950 rounded-xl text-[11px] font-bold dark:text-white outline-none border border-transparent focus:border-indigo-600" />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[8px] font-black text-slate-400 uppercase tracking-widest ml-1">Entrada 2</label>
                      <input type="time" value={editDayData.e2} onChange={e => setEditDayData({...editDayData, e2: e.target.value})} className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-950 rounded-xl text-[11px] font-bold dark:text-white outline-none border border-transparent focus:border-indigo-600" />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[8px] font-black text-slate-400 uppercase tracking-widest ml-1">Saída 2</label>
                      <input type="time" value={editDayData.s2} onChange={e => setEditDayData({...editDayData, s2: e.target.value})} className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-950 rounded-xl text-[11px] font-bold dark:text-white outline-none border border-transparent focus:border-indigo-600" />
                    </div>
                  </div>
                  <div className="space-y-1">
                    <label className="text-[8px] font-black text-slate-400 uppercase tracking-widest ml-1">Observações</label>
                    <textarea value={editDayData.notes} onChange={e => setEditDayData({...editDayData, notes: e.target.value})} placeholder="Notas do dia..." className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-950 rounded-xl text-[11px] font-bold dark:text-white h-24 resize-none outline-none border border-transparent focus:border-indigo-600 shadow-inner" />
                  </div>
                  <div className="flex gap-3 pt-4">
                    <button type="button" onClick={() => setEditDayData(null)} className="flex-1 py-3 text-[10px] font-black uppercase text-slate-400">Voltar</button>
                    <button type="submit" className="flex-[2] bg-indigo-600 text-white py-3 rounded-xl text-[10px] font-black uppercase tracking-widest shadow-xl">Guardar Alterações</button>
                  </div>
                </form>
              </div>
            </div>
          )}

          {showClearModal && (
            <div className="fixed inset-0 bg-slate-950/90 backdrop-blur-xl z-[250] flex items-center justify-center p-4">
              <div className="bg-white dark:bg-slate-900 rounded-[2rem] shadow-2xl max-w-sm w-full p-10 text-center border dark:border-white/5 animate-slide-up">
                <h3 className="text-lg font-black text-slate-900 dark:text-white uppercase mb-4 italic">Limpar Picagens?</h3>
                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mb-8">Deseja apagar todos os registos de ponto? As ausências (férias, faltas, etc.) serão preservadas.</p>
                <div className="flex flex-col gap-3">
                  <button onClick={() => { onClearPunches(); setShowClearModal(false); }} className="w-full bg-rose-600 text-white py-4 rounded-xl text-[10px] font-black uppercase shadow-lg">Confirmar Limpeza de Picagens</button>
                  <button onClick={() => setShowClearModal(false)} className="w-full py-4 text-[10px] font-black uppercase text-slate-400">Cancelar</button>
                </div>
              </div>
            </div>
          )}

          {showClearAllModal && (
            <div className="fixed inset-0 bg-slate-950/90 backdrop-blur-xl z-[250] flex items-center justify-center p-4">
              <div className="bg-white dark:bg-slate-900 rounded-[2rem] shadow-2xl max-w-sm w-full p-10 text-center border dark:border-white/5 animate-slide-up">
                <h3 className="text-lg font-black text-rose-600 uppercase mb-4 italic">Limpeza Total?</h3>
                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mb-8">Esta ação apagará TODAS as picagens e TODAS as ausências (férias, faltas, etc.). Esta ação é irreversível.</p>
                <div className="flex flex-col gap-3">
                  <button onClick={() => { onClearAll(); setShowClearAllModal(false); }} className="w-full bg-rose-600 text-white py-4 rounded-xl text-[10px] font-black uppercase shadow-lg">Confirmar Limpeza Total</button>
                  <button onClick={() => setShowClearAllModal(false)} className="w-full py-4 text-[10px] font-black uppercase text-slate-400">Cancelar</button>
                </div>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
};

export default SettingsView;
