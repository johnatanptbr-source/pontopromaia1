
import { AbsenceRecord } from '../types';

export const getPortugueseHolidays = (year: number): { date: string, name: string }[] => {
  const holidays = [
    { date: `${year}-01-01`, name: 'Ano Novo' },
    { date: `${year}-04-25`, name: 'Dia da Liberdade' },
    { date: `${year}-05-01`, name: 'Dia do Trabalhador' },
    { date: `${year}-06-10`, name: 'Dia de Portugal' },
    { date: `${year}-08-15`, name: 'Assunção de Nossa Senhora' },
    { date: `${year}-10-05`, name: 'Implantação da República' },
    { date: `${year}-11-01`, name: 'Todos os Santos' },
    { date: `${year}-12-01`, name: 'Restauração da Independência' },
    { date: `${year}-12-08`, name: 'Imaculada Conceição' },
    { date: `${year}-12-25`, name: 'Natal' },
  ];

  // Movable holidays calculation (Easter based)
  const easter = getEaster(year);
  const goodFriday = new Date(easter);
  goodFriday.setDate(easter.getDate() - 2);
  
  const corpusChristi = new Date(easter);
  corpusChristi.setDate(easter.getDate() + 60);

  const carnaval = new Date(easter);
  carnaval.setDate(easter.getDate() - 47);

  holidays.push({ date: formatDate(goodFriday), name: 'Sexta-feira Santa' });
  holidays.push({ date: formatDate(easter), name: 'Páscoa' });
  holidays.push({ date: formatDate(corpusChristi), name: 'Corpo de Deus' });
  holidays.push({ date: formatDate(carnaval), name: 'Carnaval' });

  return holidays;
};

const getEaster = (year: number): Date => {
  const f = Math.floor,
    G = year % 19,
    C = f(year / 100),
    H = (C - f(C / 4) - f((8 * C + 13) / 25) + 19 * G + 15) % 30,
    I = H - f(H / 28) * (1 - f(29 / (H + 1)) * f((21 - G) / 11)),
    J = (year + f(year / 4) + I + 2 - C + f(C / 4)) % 7,
    L = I - J,
    month = 3 + f((L + 40) / 44),
    day = L + 28 - 31 * f(month / 4);

  return new Date(year, month - 1, day);
};

const formatDate = (date: Date): string => {
  return date.toISOString().split('T')[0];
};

export const isWeekend = (dateStr: string): boolean => {
  const date = new Date(dateStr);
  const day = date.getDay(); // 0 is Sunday, 6 is Saturday
  return day === 0 || day === 6;
};

export const getHolidayName = (dateStr: string): string | null => {
  const year = new Date(dateStr).getFullYear();
  const holidays = getPortugueseHolidays(year);
  const holiday = holidays.find(h => h.date === dateStr);
  return holiday ? holiday.name : null;
};
